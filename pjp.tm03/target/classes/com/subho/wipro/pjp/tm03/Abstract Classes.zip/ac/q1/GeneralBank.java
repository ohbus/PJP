/**
 * Subhrodip Mohanta
 * hello@subho.xyz
 */
package com.subho.wipro.pjp.tm03.ac.q1;

/**
 * @author subho
 *
 */
public abstract class GeneralBank {
	
	public abstract double getSavingsInterestRate();
	
	public abstract double getFixedDepositInterestRate();
	
}