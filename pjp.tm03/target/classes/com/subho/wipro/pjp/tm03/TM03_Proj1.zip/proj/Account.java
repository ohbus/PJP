package com.subho.wipro.pjp.tm03.proj;

public abstract class Account {
	double interestRate;
	double amount;
	
	abstract double calculateInterest();

}