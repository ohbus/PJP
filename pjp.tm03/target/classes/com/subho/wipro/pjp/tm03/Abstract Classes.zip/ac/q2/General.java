package com.subho.wipro.pjp.tm03.ac.q2;

public class General extends Compartment{

	public String notice() {
		
		return "This is a General compartment.";
	}
}