package com.subho.wipro.pjp.tm03.ac.q2;

public abstract class Compartment {
	
	public abstract String notice();
	
}