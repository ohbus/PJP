/**
 * Subhrodip Mohanta
 * hello@subho.xyz
 */
package com.subho.wipro.pjp.tm03.ac.q2;

/**
 * @author subho
 *
 */

public class FirstClass extends Compartment{
	
	public String notice() {
		
		return "This is a First class compartment." ; 
	}

}