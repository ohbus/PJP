package com.subho.wipro.pjp.tm03.Packages.q1;

import com.subho.wipro.pjp.tm03.Packages.q1.testpackage.foundation;

public class test {

	public static void main(String[] args) {
		foundation f = new foundation();
		//System.out.println(f.var1);
		//System.out.println(f.var2);
		//System.out.println(f.var3);
		System.out.println(f.var4);

	}

}
