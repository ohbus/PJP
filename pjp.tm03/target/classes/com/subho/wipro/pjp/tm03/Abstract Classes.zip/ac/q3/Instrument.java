package com.subho.wipro.pjp.tm03.ac.q3;

public abstract class Instrument {
	
	public abstract void play();

}