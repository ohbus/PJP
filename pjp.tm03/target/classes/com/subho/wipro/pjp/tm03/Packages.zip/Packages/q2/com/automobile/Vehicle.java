package com.subho.wipro.pjp.tm03.Packages.q2.com.automobile;

public abstract class Vehicle {
	public abstract String getModelNumber();
	public abstract String getRegistrationNumber();
	public abstract String getOwnerName();
}
