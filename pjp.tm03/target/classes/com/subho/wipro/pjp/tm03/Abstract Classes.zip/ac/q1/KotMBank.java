package com.subho.wipro.pjp.tm03.ac.q1;

public class KotMBank extends GeneralBank {
	
	public double getFixedDepositInterestRate() {
		
		return 6;
	}
	
	public double getSavingsInterestRate() {
		
		return 9;
	}

}