package com.subho.wipro.pjp.tm03.Interfaces.q2.music.wind;

import com.subho.wipro.pjp.tm03.Interfaces.q2.music.Playable;

public class Saxophone implements Playable{
	public void play()
	{
		System.out.println("Saxophone playing");
	}
}
