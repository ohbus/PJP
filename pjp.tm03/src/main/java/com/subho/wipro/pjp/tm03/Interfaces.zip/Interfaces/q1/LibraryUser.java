package com.subho.wipro.pjp.tm03.Interfaces.q1;

public interface LibraryUser {
	public void registerAccount();
	public void requestBook();
}
