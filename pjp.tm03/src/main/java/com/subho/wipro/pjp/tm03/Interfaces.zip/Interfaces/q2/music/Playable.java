package com.subho.wipro.pjp.tm03.Interfaces.q2.music;

public interface Playable {
	void play();
}
