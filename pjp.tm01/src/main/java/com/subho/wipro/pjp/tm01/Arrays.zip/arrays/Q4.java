package com.subho.wipro.pjp.tm01.arrays;

public class Q4 {
	 public static void main(String[] args) {
		 int[] arr = new int[] {65, 66, 69, 70};
		 for(int num : arr) {
			 System.out.print((char)num + " ");
		 }
	 }
 }