package com.subho.wipro.pjp.tm01.arrays;

import java.util.Arrays;

public class Q6 {
	 public static void main(String[] args) {
		 int[] arr = new int[] {65, 66, 23, 790, -1, 43, -3};
		 Arrays.sort(arr);
		 for(int num : arr) {
			 System.out.println(num);
		 }
	 }	 
 }