package com.subho.wipro.pjp.tm01.fcs;

public class Q11 {
	public static void main(String[] args) {
		for(int i=24; i<=57; i+=2){
			System.out.println(i);
		}
	}
}