package com.subho.wipro.pjp.tm02.stringbuffer;

public class Q5 {
	public static void main(String [] args) {
		String str = "Suman";
		System.out.println(str.substring(1, str.length()-1));
	}
}