package com.subho.wipro.pjp.tm02.inheritance.q2;

public class Person {
	String name;
	
	Person(String name){
		this.name = name;
	}
}
