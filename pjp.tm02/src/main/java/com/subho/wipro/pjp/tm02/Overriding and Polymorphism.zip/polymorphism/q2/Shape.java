package com.subho.wipro.pjp.tm02.polymorphism.q2;

public class Shape {
	
	public void draw() {
		// Drawing Shape haha xD;
	}
	
	public void erase() {
		// Erasing shape haha xD;
	}

}
